<?php
$cari=$_GET['cari'];
header("location: tab_rekam.php?cari=$cari");
?>
