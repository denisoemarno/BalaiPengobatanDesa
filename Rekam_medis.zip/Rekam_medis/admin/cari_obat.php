<?php
$cari=$_GET['cari'];
header("location: tab_obat.php?cari=$cari");
?>
