<?php
$cari=$_GET['cari'];
header("location: tab_pasien.php?cari=$cari");
?>
