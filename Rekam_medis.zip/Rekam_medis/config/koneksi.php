<?php

// Ini Adalah Code Menghubungkan Dengan Database

  $conn = mysqli_connect('localhost','root','root','rekam_medis') or die($conn);
  

?>
